-- =====================================================================
-- 06_monitor.sql   Day-to-day checks (owner schema or DBA)
-- =====================================================================

-- Latest run, one row per segment
SELECT TO_CHAR(run_ts, 'DD-MON HH24:MI') AS run_at, segment_name, status,
       free_before_gb, allocated_gb, free_after_gb, growth_gb_day, target_gb,
       ts_avail_gb, elapsed_s, message
FROM   xx_prealloc_log
WHERE  run_id = (SELECT MAX(run_id) FROM xx_prealloc_log)
ORDER  BY log_id;

-- Space allocated per segment per day, last 14 days (the reserve the job paid for)
SELECT TRUNC(run_ts) AS day, segment_name,
       SUM(allocated_gb) AS allocated_gb,
       MIN(free_before_gb) AS lowest_free_gb
FROM   xx_prealloc_log
WHERE  run_ts >= SYSTIMESTAMP - 14
GROUP  BY TRUNC(run_ts), segment_name
ORDER  BY day DESC, segment_name;

-- Anything that did not go cleanly
SELECT TO_CHAR(run_ts, 'DD-MON HH24:MI') AS run_at, segment_name, status, message
FROM   xx_prealloc_log
WHERE  status IN ('WARNING', 'ERROR')
AND    run_ts >= SYSTIMESTAMP - 14
ORDER  BY run_ts DESC;

-- Job run history
SELECT TO_CHAR(actual_start_date, 'DD-MON HH24:MI') AS started, status,
       run_duration, SUBSTR(additional_info, 1, 200) AS info
FROM   user_scheduler_job_run_details
WHERE  job_name = 'XX_PREALLOC_JOB'
ORDER  BY actual_start_date DESC
FETCH FIRST 20 ROWS ONLY;

-- Free space above the HWM right now, without running the job
SELECT segment_name,
       ROUND(xx_seg_prealloc.free_above_hwm_gb(segment_owner, segment_name, segment_type), 2) AS free_gb,
       ROUND(xx_seg_prealloc.daily_growth_gb(segment_owner, segment_name), 2)              AS growth_gb_day,
       min_free_gb, target_free_gb
FROM   xx_prealloc_config
WHERE  enabled = 'Y';

-- Proof it works: HW contention should stay near zero in the bursts.
-- Compare the AWR "enq: HW - contention" line for 16:00-18:00 day by day.
