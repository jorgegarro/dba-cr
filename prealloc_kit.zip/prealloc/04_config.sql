-- =====================================================================
-- 04_config.sql   Run as the owner schema (XXWS_DBA) in the PDB PWS1E
--
-- Step A: confirm which 3 indexes were pre-allocated on 21 Oct (2 GB each).
--         They show a single AWR interval with about 2 GB allocated.
-- Step B: set their names below and run the inserts.
--
-- Starting values, from the 19-23 Oct analysis:
--   GL_JE_LINES : 20 GB lasted about 1.5 days, so about 13 GB/day today.
--                 Refill below 10 GB, up to 2 days of growth (min 30 GB).
--   Indexes     : refill below 1 GB, up to 2 days of growth (min 4 GB).
-- DAYS_OF_COVER makes the target follow real growth, so it adjusts at 2x
-- volume without editing this table.
-- =====================================================================

-- Step A: which GL_JE_LINES indexes received a large one-off allocation since 21 Oct
SELECT o.object_name,
       TO_CHAR(sn.end_interval_time, 'DD-MON HH24:MI')   AS snap_end,
       ROUND(s.space_allocated_delta / POWER(1024, 3), 2) AS allocated_gb
FROM   dba_hist_seg_stat     s
JOIN   dba_hist_seg_stat_obj o
       ON o.dbid = s.dbid AND o.ts# = s.ts# AND o.obj# = s.obj# AND o.dataobj# = s.dataobj#
JOIN   dba_hist_snapshot     sn
       ON sn.dbid = s.dbid AND sn.snap_id = s.snap_id AND sn.instance_number = s.instance_number
JOIN   dba_indexes           i
       ON i.owner = o.owner AND i.index_name = o.object_name
WHERE  i.table_owner = 'GL'
AND    i.table_name  = 'GL_JE_LINES'
AND    sn.begin_interval_time >= TIMESTAMP '2026-10-21 00:00:00'
AND    s.space_allocated_delta >= 1.5 * POWER(1024, 3)
ORDER  BY sn.end_interval_time, o.object_name;

-- Step B: set the three index names, then run the rest of the script
DEFINE idx1 = REPLACE_WITH_INDEX_1
DEFINE idx2 = REPLACE_WITH_INDEX_2
DEFINE idx3 = REPLACE_WITH_INDEX_3

INSERT INTO xx_prealloc_config
  (segment_owner, segment_name, segment_type, min_free_gb, target_free_gb,
   days_of_cover, chunk_gb, max_alloc_gb_per_run, enabled, notes)
VALUES
  ('GL', 'GL_JE_LINES', 'TABLE', 10, 30, 2, 1, 40, 'Y',
   'Journal lines table; 128 KB uniform extents in APPS_TS_TX_DATA');

INSERT INTO xx_prealloc_config
  (segment_owner, segment_name, segment_type, min_free_gb, target_free_gb,
   days_of_cover, chunk_gb, max_alloc_gb_per_run, enabled, notes)
VALUES ('GL', '&idx1', 'INDEX', 1, 4, 2, 0.5, 8, 'Y', 'Pre-allocated on 21 Oct');

INSERT INTO xx_prealloc_config
  (segment_owner, segment_name, segment_type, min_free_gb, target_free_gb,
   days_of_cover, chunk_gb, max_alloc_gb_per_run, enabled, notes)
VALUES ('GL', '&idx2', 'INDEX', 1, 4, 2, 0.5, 8, 'Y', 'Pre-allocated on 21 Oct');

INSERT INTO xx_prealloc_config
  (segment_owner, segment_name, segment_type, min_free_gb, target_free_gb,
   days_of_cover, chunk_gb, max_alloc_gb_per_run, enabled, notes)
VALUES ('GL', '&idx3', 'INDEX', 1, 4, 2, 0.5, 8, 'Y', 'Pre-allocated on 21 Oct');

COMMIT;

-- Adding another segment later (for example the busiest index, IDX1587700031):
--   INSERT INTO xx_prealloc_config (segment_owner, segment_name, segment_type,
--     min_free_gb, target_free_gb, days_of_cover, chunk_gb, max_alloc_gb_per_run)
--   VALUES ('GL', 'IDX1587700031', 'INDEX', 1, 4, 2, 0.5, 8);
-- Before dropping an index from the removal plan, disable its row first:
--   UPDATE xx_prealloc_config SET enabled = 'N' WHERE segment_name = 'GL_JE_LINES_A1';
