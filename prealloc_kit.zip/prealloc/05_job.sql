-- =====================================================================
-- 05_job.sql   Run as the owner schema (XXWS_DBA) in the PDB PWS1E
--
-- 1. Dry run first and review the log.
-- 2. Create the job: 06:30, 14:30 and 21:30 every day (database time zone),
--    so the reserve is full before the 16:00-18:00 burst and the
--    23:00-02:00 night window, and never runs inside them.
-- =====================================================================

-- 1. Dry run: measures and logs, allocates nothing
EXEC xx_seg_prealloc.run(p_dry_run => 'Y');

SELECT segment_name, status, free_before_gb, growth_gb_day, target_gb,
       ts_avail_gb, message
FROM   xx_prealloc_log
WHERE  run_id = (SELECT MAX(run_id) FROM xx_prealloc_log)
ORDER  BY log_id;

-- 2. Scheduler job
BEGIN
  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'XX_PREALLOC_JOB',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN xx_seg_prealloc.run; END;',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=DAILY;BYHOUR=6,14,21;BYMINUTE=30;BYSECOND=0',
    enabled         => FALSE,
    comments        => 'Keeps free space above the HWM of GL_JE_LINES and its busiest indexes (see XX_PREALLOC_CONFIG)');

  DBMS_SCHEDULER.SET_ATTRIBUTE('XX_PREALLOC_JOB', 'max_run_duration', INTERVAL '60' MINUTE);
  DBMS_SCHEDULER.SET_ATTRIBUTE('XX_PREALLOC_JOB', 'logging_level',    DBMS_SCHEDULER.LOGGING_FULL);
  DBMS_SCHEDULER.ENABLE('XX_PREALLOC_JOB');
END;
/

-- Confirm the next run times are in the expected time zone
SELECT job_name, enabled, state, next_run_date
FROM   user_scheduler_jobs
WHERE  job_name = 'XX_PREALLOC_JOB';

-- Optional: run once now instead of waiting for the next slot
-- EXEC DBMS_SCHEDULER.RUN_JOB('XX_PREALLOC_JOB', use_current_session => FALSE);
