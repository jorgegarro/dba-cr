-- =====================================================================
-- 99_uninstall.sql   Removes the job and its objects (owner schema).
-- Space already allocated stays with the segments and is used normally.
-- =====================================================================
BEGIN
  DBMS_SCHEDULER.DROP_JOB('XX_PREALLOC_JOB', force => TRUE);
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
DROP PACKAGE xx_seg_prealloc;
DROP TABLE xx_prealloc_log PURGE;
DROP TABLE xx_prealloc_config PURGE;
DROP SEQUENCE xx_prealloc_run_seq;

-- To pause instead of removing:
--   EXEC DBMS_SCHEDULER.DISABLE('XX_PREALLOC_JOB');
