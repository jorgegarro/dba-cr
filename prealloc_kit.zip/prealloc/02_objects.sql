-- =====================================================================
-- 02_objects.sql   Run as the owner schema (XXWS_DBA) in the PDB PWS1E
-- Config table, log table and run sequence.
-- =====================================================================
WHENEVER SQLERROR EXIT FAILURE

CREATE TABLE xx_prealloc_config (
  segment_owner         VARCHAR2(128) NOT NULL,
  segment_name          VARCHAR2(128) NOT NULL,
  segment_type          VARCHAR2(10)  NOT NULL
                        CONSTRAINT xx_prealloc_cfg_type_ck CHECK (segment_type IN ('TABLE','INDEX')),
  min_free_gb           NUMBER        NOT NULL,  -- top up when free space above the HWM falls below this
  target_free_gb        NUMBER        NOT NULL,  -- top up to at least this much free space
  days_of_cover         NUMBER,                  -- optional: target = max(target_free_gb, days x avg daily growth)
  chunk_gb              NUMBER        DEFAULT 1  NOT NULL,  -- size of each ALLOCATE EXTENT statement
  max_alloc_gb_per_run  NUMBER        DEFAULT 40 NOT NULL,  -- safety cap per run
  enabled               VARCHAR2(1)   DEFAULT 'Y' NOT NULL
                        CONSTRAINT xx_prealloc_cfg_enabled_ck CHECK (enabled IN ('Y','N')),
  notes                 VARCHAR2(400),
  CONSTRAINT xx_prealloc_config_pk PRIMARY KEY (segment_owner, segment_name),
  CONSTRAINT xx_prealloc_cfg_size_ck CHECK (min_free_gb >= 0 AND target_free_gb >= min_free_gb
                                            AND chunk_gb > 0 AND max_alloc_gb_per_run > 0)
);

CREATE TABLE xx_prealloc_log (
  log_id          NUMBER GENERATED ALWAYS AS IDENTITY
                  CONSTRAINT xx_prealloc_log_pk PRIMARY KEY,
  run_id          NUMBER        NOT NULL,
  run_ts          TIMESTAMP     DEFAULT SYSTIMESTAMP NOT NULL,
  segment_owner   VARCHAR2(128),
  segment_name    VARCHAR2(128),
  segment_type    VARCHAR2(10),
  free_before_gb  NUMBER,        -- allocated but unused space above the HWM, before
  growth_gb_day   NUMBER,        -- average space used per day, last 7 days (AWR)
  target_gb       NUMBER,
  allocated_gb    NUMBER,
  free_after_gb   NUMBER,
  ts_avail_gb     NUMBER,        -- tablespace free + autoextend headroom, before
  status          VARCHAR2(10),  -- OK | ALLOCATED | DRY RUN | WARNING | ERROR
  message         VARCHAR2(4000),
  elapsed_s       NUMBER
);

CREATE INDEX xx_prealloc_log_n1 ON xx_prealloc_log (run_ts);

CREATE SEQUENCE xx_prealloc_run_seq NOCACHE;
