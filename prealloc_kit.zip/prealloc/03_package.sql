-- =====================================================================
-- 03_package.sql   Run as the owner schema (XXWS_DBA) in the PDB PWS1E
--
-- XX_SEG_PREALLOC keeps a reserve of empty, already-allocated space above
-- the high-water mark of each segment listed in XX_PREALLOC_CONFIG, so the
-- Journal Import bursts do not wait on "enq: HW - contention".
--
-- For each enabled segment, each run:
--   1. measures free space above the HWM (DBMS_SPACE.UNUSED_SPACE)
--   2. if it is below MIN_FREE_GB, works out a target:
--        max(TARGET_FREE_GB, DAYS_OF_COVER x average daily growth from AWR)
--   3. checks the tablespace has room (free + autoextend headroom,
--      keeping G_TS_RESERVE_GB untouched)
--   4. runs ALTER TABLE|INDEX ... ALLOCATE EXTENT (SIZE n M) in CHUNK_GB
--      steps, never more than MAX_ALLOC_GB_PER_RUN
--   5. writes one row per segment to XX_PREALLOC_LOG
-- A run with any ERROR ends with ORA-20001, so the scheduler job shows
-- FAILED and existing job-failure alerting picks it up.
-- =====================================================================
WHENEVER SQLERROR EXIT FAILURE

CREATE OR REPLACE PACKAGE xx_seg_prealloc AUTHID DEFINER AS

  -- Space always left free in the tablespace (GB), never allocated by the job
  g_ts_reserve_gb  NUMBER := 50;

  -- Main entry point, called by the scheduler job.
  -- p_dry_run => 'Y' measures and logs what it would do, allocates nothing.
  PROCEDURE run (p_dry_run IN VARCHAR2 DEFAULT 'N');

  -- Free space above the HWM of one segment, in GB
  FUNCTION free_above_hwm_gb (p_owner IN VARCHAR2,
                              p_name  IN VARCHAR2,
                              p_type  IN VARCHAR2) RETURN NUMBER;

  -- Average space used per day over the last p_days days (AWR), in GB; NULL if unknown
  FUNCTION daily_growth_gb (p_owner IN VARCHAR2,
                            p_name  IN VARCHAR2,
                            p_days  IN NUMBER DEFAULT 7) RETURN NUMBER;

END xx_seg_prealloc;
/

CREATE OR REPLACE PACKAGE BODY xx_seg_prealloc AS

  c_gb CONSTANT NUMBER := 1024 * 1024 * 1024;

  -- -------------------------------------------------------------------
  PROCEDURE log_row (p_run_id   IN NUMBER,
                     p_owner    IN VARCHAR2,
                     p_name     IN VARCHAR2,
                     p_type     IN VARCHAR2,
                     p_before   IN NUMBER,
                     p_growth   IN NUMBER,
                     p_target   IN NUMBER,
                     p_alloc    IN NUMBER,
                     p_after    IN NUMBER,
                     p_ts_avail IN NUMBER,
                     p_status   IN VARCHAR2,
                     p_message  IN VARCHAR2,
                     p_elapsed  IN NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO xx_prealloc_log
      (run_id, segment_owner, segment_name, segment_type, free_before_gb,
       growth_gb_day, target_gb, allocated_gb, free_after_gb, ts_avail_gb,
       status, message, elapsed_s)
    VALUES
      (p_run_id, p_owner, p_name, p_type, ROUND(p_before, 2),
       ROUND(p_growth, 2), ROUND(p_target, 2), ROUND(p_alloc, 2), ROUND(p_after, 2),
       ROUND(p_ts_avail, 1), p_status, SUBSTR(p_message, 1, 4000), ROUND(p_elapsed, 1));
    COMMIT;
  END log_row;

  -- -------------------------------------------------------------------
  FUNCTION free_above_hwm_gb (p_owner IN VARCHAR2,
                              p_name  IN VARCHAR2,
                              p_type  IN VARCHAR2) RETURN NUMBER IS
    l_total_blocks  NUMBER;
    l_total_bytes   NUMBER;
    l_unused_blocks NUMBER;
    l_unused_bytes  NUMBER;
    l_file_id       NUMBER;
    l_block_id      NUMBER;
    l_last_block    NUMBER;
  BEGIN
    DBMS_SPACE.UNUSED_SPACE(
      segment_owner             => p_owner,
      segment_name              => p_name,
      segment_type              => p_type,
      total_blocks              => l_total_blocks,
      total_bytes               => l_total_bytes,
      unused_blocks             => l_unused_blocks,
      unused_bytes              => l_unused_bytes,
      last_used_extent_file_id  => l_file_id,
      last_used_extent_block_id => l_block_id,
      last_used_block           => l_last_block);
    RETURN l_unused_bytes / c_gb;
  END free_above_hwm_gb;

  -- -------------------------------------------------------------------
  FUNCTION daily_growth_gb (p_owner IN VARCHAR2,
                            p_name  IN VARCHAR2,
                            p_days  IN NUMBER DEFAULT 7) RETURN NUMBER IS
    l_bytes NUMBER;
    l_snaps NUMBER;
  BEGIN
    SELECT SUM(s.space_used_delta), COUNT(*)
    INTO   l_bytes, l_snaps
    FROM   dba_hist_seg_stat     s
    JOIN   dba_hist_seg_stat_obj o
           ON  o.dbid     = s.dbid
           AND o.ts#      = s.ts#
           AND o.obj#     = s.obj#
           AND o.dataobj# = s.dataobj#
    JOIN   dba_hist_snapshot     sn
           ON  sn.dbid            = s.dbid
           AND sn.snap_id         = s.snap_id
           AND sn.instance_number = s.instance_number
    WHERE  o.owner        = p_owner
    AND    o.object_name  = p_name
    AND    sn.begin_interval_time >= SYSTIMESTAMP - NUMTODSINTERVAL(p_days, 'DAY');

    IF l_snaps = 0 OR l_bytes IS NULL THEN
      RETURN NULL;                     -- segment not in AWR top segments: use TARGET_FREE_GB
    END IF;
    RETURN GREATEST(l_bytes, 0) / c_gb / p_days;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;                     -- AWR not readable: fall back to TARGET_FREE_GB
  END daily_growth_gb;

  -- -------------------------------------------------------------------
  FUNCTION ts_available_gb (p_ts IN VARCHAR2) RETURN NUMBER IS
    l_free  NUMBER;
    l_extend NUMBER;
  BEGIN
    SELECT NVL(SUM(bytes), 0)
    INTO   l_free
    FROM   dba_free_space
    WHERE  tablespace_name = p_ts;

    SELECT NVL(SUM(CASE WHEN autoextensible = 'YES'
                        THEN GREATEST(maxbytes - bytes, 0) ELSE 0 END), 0)
    INTO   l_extend
    FROM   dba_data_files
    WHERE  tablespace_name = p_ts;

    RETURN (l_free + l_extend) / c_gb;
  END ts_available_gb;

  -- -------------------------------------------------------------------
  PROCEDURE run (p_dry_run IN VARCHAR2 DEFAULT 'N') IS
    l_run_id  NUMBER := xx_prealloc_run_seq.NEXTVAL;
    l_errors  PLS_INTEGER := 0;
    l_dry     BOOLEAN := UPPER(NVL(p_dry_run, 'N')) = 'Y';
  BEGIN
    -- Wait up to 60 s for the brief lock ALLOCATE EXTENT needs, instead of failing
    EXECUTE IMMEDIATE 'ALTER SESSION SET ddl_lock_timeout = 60';

    FOR c IN (SELECT *
              FROM   xx_prealloc_config
              WHERE  enabled = 'Y'
              ORDER  BY DECODE(segment_type, 'TABLE', 1, 2), segment_name)
    LOOP
      DECLARE
        l_start    NUMBER := DBMS_UTILITY.GET_TIME;
        l_free     NUMBER;
        l_after    NUMBER;
        l_growth   NUMBER;
        l_target   NUMBER;
        l_need     NUMBER := 0;
        l_alloc    NUMBER := 0;
        l_chunk    NUMBER;
        l_ts       dba_segments.tablespace_name%TYPE;
        l_ts_avail NUMBER;
        l_status   VARCHAR2(10);
        l_msg      VARCHAR2(4000);
        l_obj      VARCHAR2(300);
      BEGIN
        l_obj := DBMS_ASSERT.ENQUOTE_NAME(c.segment_owner, FALSE) || '.' ||
                 DBMS_ASSERT.ENQUOTE_NAME(c.segment_name,  FALSE);

        SELECT tablespace_name
        INTO   l_ts
        FROM   dba_segments
        WHERE  owner        = c.segment_owner
        AND    segment_name = c.segment_name
        AND    segment_type = c.segment_type;

        l_free   := free_above_hwm_gb(c.segment_owner, c.segment_name, c.segment_type);
        l_growth := CASE WHEN c.days_of_cover IS NOT NULL
                         THEN daily_growth_gb(c.segment_owner, c.segment_name) END;
        l_target := GREATEST(c.target_free_gb, NVL(c.days_of_cover * l_growth, 0));

        IF l_free >= c.min_free_gb THEN
          l_status := 'OK';
          l_msg    := 'Free space above HWM is at or above MIN_FREE_GB (' || c.min_free_gb || ' GB)';
        ELSE
          l_need     := LEAST(CEIL((l_target - l_free) / c.chunk_gb) * c.chunk_gb,
                              c.max_alloc_gb_per_run);
          l_ts_avail := ts_available_gb(l_ts);

          IF l_ts_avail - l_need < g_ts_reserve_gb THEN
            l_need := GREATEST(FLOOR((l_ts_avail - g_ts_reserve_gb) / c.chunk_gb) * c.chunk_gb, 0);
            l_status := CASE WHEN l_need > 0 THEN 'WARNING' ELSE 'ERROR' END;
            l_msg    := 'Tablespace ' || l_ts || ' has only ' || ROUND(l_ts_avail, 1) ||
                        ' GB available (reserve ' || g_ts_reserve_gb || ' GB); add space to the tablespace';
          END IF;

          IF l_dry THEN
            l_status := 'DRY RUN';
            l_msg    := 'Would allocate ' || l_need || ' GB in ' || c.chunk_gb || ' GB steps. ' || l_msg;
          ELSE
            WHILE l_alloc < l_need LOOP
              l_chunk := LEAST(c.chunk_gb, l_need - l_alloc);
              EXECUTE IMMEDIATE 'ALTER ' || c.segment_type || ' ' || l_obj ||
                                ' ALLOCATE EXTENT (SIZE ' || TO_CHAR(ROUND(l_chunk * 1024)) || 'M)';
              l_alloc := l_alloc + l_chunk;
            END LOOP;
            IF l_status IS NULL THEN
              l_status := 'ALLOCATED';
              l_msg    := 'Allocated ' || l_alloc || ' GB in ' || c.chunk_gb || ' GB steps';
            END IF;
          END IF;
        END IF;

        IF l_status = 'ERROR' THEN
          l_errors := l_errors + 1;
        END IF;

        l_after := CASE WHEN l_alloc > 0
                        THEN free_above_hwm_gb(c.segment_owner, c.segment_name, c.segment_type)
                        ELSE l_free END;

        log_row(l_run_id, c.segment_owner, c.segment_name, c.segment_type, l_free,
                l_growth, l_target, l_alloc, l_after, l_ts_avail, l_status, l_msg,
                (DBMS_UTILITY.GET_TIME - l_start) / 100);
      EXCEPTION
        WHEN OTHERS THEN
          l_errors := l_errors + 1;
          log_row(l_run_id, c.segment_owner, c.segment_name, c.segment_type, l_free,
                  l_growth, l_target, l_alloc, NULL, l_ts_avail, 'ERROR',
                  'After ' || l_alloc || ' GB allocated: ' || SQLERRM,
                  (DBMS_UTILITY.GET_TIME - l_start) / 100);
      END;
    END LOOP;

    IF l_errors > 0 THEN
      RAISE_APPLICATION_ERROR(-20001, l_errors || ' segment(s) failed; see XX_PREALLOC_LOG run_id ' || l_run_id);
    END IF;
  END run;

END xx_seg_prealloc;
/

SHOW ERRORS PACKAGE BODY xx_seg_prealloc
