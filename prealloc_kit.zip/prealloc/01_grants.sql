-- =====================================================================
-- 01_grants.sql   Run as SYS (or a DBA) connected to the PDB PWS1E
--
-- Privileges the owner schema needs to check free space and allocate
-- extents on GL.GL_JE_LINES and its indexes. Grants are direct (not via
-- roles) because the package runs with definer's rights.
--
-- If your security standard does not allow ANY privileges for a custom
-- schema, install every script under SYSTEM instead (set app_owner below).
-- =====================================================================
WHENEVER SQLERROR EXIT FAILURE
DEFINE app_owner = XXWS_DBA

GRANT CREATE TABLE, CREATE SEQUENCE, CREATE PROCEDURE, CREATE JOB TO &app_owner;
GRANT ALTER ANY TABLE  TO &app_owner;   -- ALTER TABLE gl.gl_je_lines ALLOCATE EXTENT
GRANT ALTER ANY INDEX  TO &app_owner;   -- ALTER INDEX gl.<index>   ALLOCATE EXTENT
GRANT ANALYZE ANY      TO &app_owner;   -- DBMS_SPACE.UNUSED_SPACE on another schema's segments

GRANT SELECT ON sys.dba_segments          TO &app_owner;
GRANT SELECT ON sys.dba_free_space        TO &app_owner;
GRANT SELECT ON sys.dba_data_files        TO &app_owner;
GRANT SELECT ON sys.dba_hist_seg_stat     TO &app_owner;  -- daily growth (Diagnostics Pack)
GRANT SELECT ON sys.dba_hist_seg_stat_obj TO &app_owner;
GRANT SELECT ON sys.dba_hist_snapshot     TO &app_owner;
GRANT SELECT ON sys.dba_indexes           TO &app_owner;  -- used by the finder query in 04_config.sql

-- The two control tables are small (KBs per day of log). Make sure the
-- owner has quota on its default tablespace, for example:
--   ALTER USER &app_owner QUOTA 100M ON <its default tablespace>;
